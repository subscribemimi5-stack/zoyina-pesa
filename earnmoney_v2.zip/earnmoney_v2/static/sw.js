/**
 * sw.js — Service Worker ya Zoyina Pesa PWA
 * Weka faili hii kwenye: static/sw.js
 */

const CACHE_NAME = 'zoyina-pesa-v1';

const SHELL_URLS = [
  '/',
  '/login_page',
  '/static/manifest.json',
];

// ── Install ──
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(SHELL_URLS).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

// ── Activate: futa cache za zamani ──
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// ── Fetch: Network-first, cache fallback ──
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Ruka requests za admin, POST, na external
  if (
    url.pathname.startsWith('/admin') ||
    request.method !== 'GET' ||
    url.origin !== location.origin
  ) return;

  event.respondWith(
    fetch(request)
      .then(response => {
        if (response.ok && url.pathname.startsWith('/static/')) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(c => c.put(request, clone));
        }
        return response;
      })
      .catch(() =>
        caches.match(request).then(cached => cached || new Response(
          `<!DOCTYPE html><html lang="sw"><head>
          <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
          <title>Hakuna Mtandao</title>
          <style>
            body{margin:0;background:#0a0a0a;color:#fff;font-family:sans-serif;
                 display:flex;flex-direction:column;align-items:center;
                 justify-content:center;min-height:100vh;text-align:center;padding:20px}
            .ico{font-size:64px;margin-bottom:16px}
            h1{color:#00C853;margin:0 0 8px}p{color:#aaa;margin:0 0 24px}
            button{background:#00C853;color:#000;border:none;padding:12px 28px;
                   border-radius:8px;font-size:1rem;font-weight:700;cursor:pointer}
          </style></head>
          <body>
            <div class="ico">📵</div>
            <h1>Hakuna Mtandao</h1>
            <p>Angalia muunganiko wako kisha jaribu tena.</p>
            <button onclick="location.reload()">🔄 Jaribu Tena</button>
          </body></html>`,
          { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
        ))
      )
  );
});
